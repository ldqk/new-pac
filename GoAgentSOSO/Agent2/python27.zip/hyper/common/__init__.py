# -*- coding: utf-8 -*-
"""
hyper/common
~~~~~~~~~~~~

Common code in hyper.
"""
